#!/bin/sh

git status --ignored -s | grep "!!" | cut -f 2 -d" "

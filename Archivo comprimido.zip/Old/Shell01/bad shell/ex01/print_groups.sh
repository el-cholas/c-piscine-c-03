#!/bin/sh

id -G -nr $FT_USER | sed "s/ /,/g"
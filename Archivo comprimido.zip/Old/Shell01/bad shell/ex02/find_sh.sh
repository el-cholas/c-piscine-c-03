#!/bin/sh

find . -name "*.sh" -type f -exec basename {} .sh ";"

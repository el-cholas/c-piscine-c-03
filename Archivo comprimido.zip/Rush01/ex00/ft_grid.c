/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_grid.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: xcarroll <xcarroll@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/02/20 15:58:23 by xcarroll          #+#    #+#             */
/*   Updated: 2022/02/20 16:01:37 by xcarroll         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	calculate_grid_size(char *str);
int	verify_input(char *str, int *grid_size, int *input_numbers);
void	print_matrix(int *matrix, int grid_size);
// void	grid_controller(int *grid_size, int *input_numbers);
// int	*get_matrix(char *str, int grid_size);
void	ft_putnbr(int nb);
void	ft_putstr(char *str);
void	ft_putchar(char c);

int start_board(char *input)
{
	int grid_size;
	int input_numbers[1];
	int error;
	//int *matrix;

	error = verify_input(input, &grid_size, input_numbers);
	// grid_controller(&grid_size, input_numbers);
	return (error);

	/* TODO: gotta free matrix eventually! */
	// matrix = get_matrix(argv[1], grid_size);
}

int	verify_input(char *input, int *grid_size, int *input_numbers)
{
	int input_pointer;
	int	i;

	*grid_size = calculate_grid_size(input);
	input_numbers = (int *) malloc(*grid_size * *grid_size * 4);
	input_pointer = 0;
	i = 0;
	ft_putstr("1\n");
	while (input[i] != '\0')
	{
		if (input[i] >= '1' && (input[i] <= *grid_size + '0'))
		{
			input_numbers[input_pointer] = input[i];
			input_pointer++;
		}
		else if (input[i] != ' ')
			ft_putstr("4\n");
			return (1);
		i++;
	}
	ft_putstr("5\n");
	if (i != *grid_size * *grid_size * 2 - 1)
		return (1);
	i = 0;
	print_matrix(input_numbers, *grid_size);
	return (0);
}

int	calculate_grid_size(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		i++;
	}
	return ((i + 1) / 8);
}

/*
	int	i;
	int	*tab;

	tab = (int *) malloc(16 * 4);
	i = 0;
	while (str[i] != '\0')
	{
		tab[i] = str[i * 2] - 0x30;
		i++;ww
	}
	*/


void	grid_controller(int *board_size, int *input_numbers)
{
	int	solving;
	int board[1][1];
	int	x;
	int	y;

	y = 0;
	while (y < *board_size - 1)
	{
		x = 0;
		while (x < *board_size - 1)
		{
			board[x][y] = -1;
			x++;
		}
		y++;
	}

	solving = 0;
	while (solving)
	{
		solving = 1;
	}
	ft_putnbr(input_numbers[0]);
}


/*
int	*get_matrix(char *str, int grid_size)
{
	int	*matrix;
	int	i;

	matrix = (int *) malloc(grid_size * grid_size * 4);
	i = 0;
	while (str[i] != '\0')
	{
		if (i % 2 == 0)
			matrix[i / 2] = str[i] - 0x30;
		i++;
	}
	return (matrix);
}
*/
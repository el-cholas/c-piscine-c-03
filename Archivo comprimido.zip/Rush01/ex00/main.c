/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: xcarroll <xcarroll@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/02/19 11:12:27 by agarrigu          #+#    #+#             */
/*   Updated: 2022/02/20 16:53:46 by agarrigu         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_putstr(char *str);
int start_board(char *input);

int	main(int argc, char *argv[])
{
	int	error;

	if (argc == 2)
	{
		error = start_board(argv[1]);
	}
	else
	{
		error = 1;
	}
	if (error)
		ft_putstr("Error\n");
}
